// KIT107 Assignment 2
/*
 * Header for the driver file
 * Author Julian Dermoudy
 * Version 21/3/22
 *
 * THIS FILE IS COMPLETE
 */

#ifndef ASSIG_TWO122_H
#define ASSIG_TWO122_H

#include <stdbool.h>
#include "node.h"
#include "score.h"
#include "quarters.h"
#include "game.h"
 

/* Types */
//typedef node quarter_format; //JRD

//typedef quarters *game_format; //JRD
#endif
