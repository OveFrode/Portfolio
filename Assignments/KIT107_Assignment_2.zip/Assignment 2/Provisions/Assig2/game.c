// KIT107 Assignment 2
/*
 * Implementation for game
 * Author Zac Partridge 597945
 * Version 04/05/2022
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"

 /* Constants */

extern const char* TEAMS[2];	// team names
extern const int NUM_QUARTERS;	// number of quarters in the game

/* Types */

struct game_int
{
	game_format the_quarters;
	int quarter_num;
};

/* Functions */

/*
* 'Constructor' for game
* Param gp pointer to game being constructed
*/
void init_game(game* gp)
{
	// create the game
	(*gp) = (game)malloc(sizeof(struct game_int));

	// create the quarters
	(*gp)->the_quarters = (game_format)malloc(NUM_QUARTERS * sizeof(quarters));

	for (int i = 0; i < NUM_QUARTERS; i++)
	{
		//calls in init_quarter (with address of the_quarters in *gp)
		init_quarter(&(((*gp)->the_quarters)[i]));
	}

	// initialise the current quarter (game is yet to start)
	(*gp)->quarter_num = 0;
}

/*
* Getter for quarters
* Param g game variable to examine
* Return the_quarters field
*/
game_format get_quarters(game g)
{
	return g->the_quarters;
}

/*
* Getter for quarter number
* Param g game variable to examine
* Return quarter_num field
*/
int get_current_quarter(game g)
{
	return g->quarter_num;
}

/*
* Setter for quarters
* Param g game variable to update
* Param q value to be placed into the game's the_quarters field
*/
void set_quarters(game g, game_format q)
{
	g->the_quarters = q;
}

/*
* Setter for quarter number
* Param g game variable to update
* Param n value to be placed into the game's quarter_num field
*/
void set_current_quarter(game g, int n)
{
	g->quarter_num = n;
}

/*
* Doer function to add a score to the game
* Param g game variable to update
* Param a_score value to be added to the game at the end of the appropriate quarter
*/
void add_score_to_game(game g, score a_score)
{
	int q;

	/*create new score*/
	q = get_quarter(a_score);

	// no score so new one will be added
	if (g->quarter_num != q)
	{
		g->quarter_num = q;

		//prints the "Quarter" and the quarter_num we are in
		printf("\nQuarter %d\n\n", q);
	}
	//prints "He shoots and..." and calls to score to_string method passing in the score and team that shot
	printf("He shoots and...%s\n", to_string(a_score, TEAMS));

	// existing list, so find the end
	if (get_worth(a_score) != 0)
	{
		//add score to the end of the list
		add_score_to_quarter(g->the_quarters[g->quarter_num - 1], a_score);
	}
}

/*
* Doer function to display vertical worm of the changing lead in the game
* Param g game variable to process
*/
void show_vert_worm(game g)
{
	node c;
	score s;

	int gap = 40; //used to get to the middle of the vertical worm
	int margin = 0; //used to add * to the code

	char heading[35];	// heading

	/* create, print, and underline heading */
	sprintf(heading, "\nVertical Worm");
	printf("%s\n", heading);
	for (int i = 0; i < strlen(heading); i++)
	{
		printf("-");
	}
	printf("\n");

	printf("%30s%20s%s\n", TEAMS[0], " ", TEAMS[1]);

	//for loop used to move though the quarters
	for (int i = 0; i < NUM_QUARTERS; i++)
	{
		c = get_scores(g->the_quarters[i]);

		while (c != NULL)
		{
			s = (score)get_data(c);

			//checks if it is team 1
			if (get_team(s) == 0)
			{
				// checks for goals else it a point
				if (get_worth(s) == 6)
				{
					margin = margin - 6;
				}
				else
				{
					margin = margin - 1;
				}
			}
			else //else it team 2
			{
				if (get_worth(s) == 6)
				{
					margin = margin + 6;
				}
				else
				{
					margin = margin + 1;
				}
			}

			/*Prints vertical worm*/
			if (margin < 0)
			{
				gap = 40 - abs(margin);
			}
			else
			{
				gap = 40;
			}

			for (int j = 0; j < gap; j++)
			{
				printf(" ");
			}
			for (int j = 0; j < abs(margin); j++)
			{
				printf("*");
			}

			printf("\n");
			c = get_next(c);
		}
	}
}
/*
* Doer function to display scores of requested and previous quarters in the game
* Param g game variable to process
*/
void show_quarter_scores(game g)
{
	node c;
	score s;

	/*keeps count of goal, point*/
	int team_one_goal_count = 0;
	int team_one_point_count = 0;
	int team_two_goal_count = 0;
	int team_two_point_count = 0;

	int choice;

	char heading[35]; // heading

	/* create, print, and underline heading */
	sprintf(heading, "\nScores up to Selected Quarter");
	printf("%s\n", heading);
	for (int i = 0; i < strlen(heading); i++)
	{
		printf("-");
	}
	printf("\n");

	/* asking the user to input a quarter number */
	printf("\nEnter quarter Number : #");
	scanf("%d", &choice);

	switch ((choice))
	{
	case 1: choice = 1;
		break;
	case 2: choice = 2;
		break;
	case 3: choice = 3;
		break;
	default:choice = 4;
		break;
	}

	//prints the number Quarter choosen by the user otherwise defaults to 4
	for (int i = 0; i < choice; i++)
	{
		c = get_scores(g->the_quarters[i]);

		//prints "Quarter" and the number of the quarter + 1 so quarters range is 1 to 4
		printf("\nQuarter %d\n", i + 1);

		while (c != NULL)
		{
			s = (score)get_data(c);

			//checks if score is for team 1
			if (get_team(s) == 0)
			{
				//checks if goal else it a point
				if (get_worth(s) == 6)
				{
					team_one_goal_count++;
				}
				else
				{
					team_one_point_count++;
				}
			}
			else //else it team 2
			{
				if (get_worth(s) == 6)
				{
					team_two_goal_count++;
				}
				else
				{
					team_two_point_count++;
				}
			}

			c = get_next(c);
		}
		/*Adds the scores per quarter together*/
		int team_one_total_count = ((team_one_goal_count * 6) + team_one_point_count);
		int team_two_total_count = ((team_two_goal_count * 6) + team_two_point_count);

		/*Prints the Goals, Points and score per quarter*/
		printf("Carlton %d %d %d \n", (team_one_goal_count * 6), (team_one_point_count), (team_one_total_count));// need to print the quaters scores
		printf("Losers  %d %d %d \n", (team_two_goal_count * 6), (team_two_point_count), (team_two_total_count));
	}
}

/*
* Doer function to calculate and display final margin in the game
* Param g game variable to process
*/
void show_final_margin(game g)
{
	node c;
	score s;

	/*keeps count of goal, point*/
	int team_one_goal_count = 0;
	int team_one_point_count = 0;
	int team_two_goal_count = 0;
	int team_two_point_count = 0;

	//holds the final margin value
	int final_margin = 0;

	//keep count of goal, point

	char heading[35]; //heading

	/* create, print, and underline heading */
	sprintf(heading, "\nFinal margin");
	printf("%s\n", heading);
	for (int i = 0; i < strlen(heading); i++)
	{
		printf("-");
	}
	printf("\n");
	for (int i = 0; i < NUM_QUARTERS; i++)
	{
		c = get_scores(g->the_quarters[i]);

		while (c != NULL)
		{
			s = (score)get_data(c);
			if (get_team(s) == 0)
			{
				if (get_worth(s) == 6)
				{
					team_one_goal_count++;
				}
				else
				{
					team_one_point_count++;
				}
			}
			else
			{
				if (get_worth(s) == 6)
				{
					team_two_goal_count++;
				}
				else
				{
					team_two_point_count++;
				}
			}

			c = get_next(c);
		}
	}

	/*Adds the scores per quarter together*/
	int team_one_total_count = ((team_one_goal_count * 6) + team_one_point_count);
	int team_two_total_count = ((team_two_goal_count * 6) + team_two_point_count);

	//if team one wins
	if (team_one_total_count > team_two_total_count)
	{
		final_margin = team_one_total_count - team_two_total_count;
		printf("Carlton wins with the final margin of: %d \n", final_margin);
	}
	else
	{
		//if team two wins
		if (team_two_total_count > team_one_total_count)
		{
			final_margin = team_two_total_count - team_one_total_count;
			printf("Losers wins with the final margin of: %d \n", final_margin);
		}
		else //else it a draw
		{
			final_margin = team_one_total_count;
			printf("It was a draw with the final margin of: %d \n", final_margin);
		}
	}
}