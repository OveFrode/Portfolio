import java.util.Scanner;
/*
 * Assignment 1
 * AssigOne122 -- Main method of assignment 1
 * @author Zac Partridge 597945 & 
 * @version 09/03/2022
 */

public class AssigOne122 {
  
  public static void displayHeading(String heading) {
    String a = heading.toUpperCase(); // makes all letters in heading Uppercase
    System.out.println(a); // prints hyphens underlining the heading
    
    for (int i = 0; i < heading.length(); i++) {
      System.out.print("-");
    }
    System.out.println();
  }
  
  public static void main(String[] args) {
    
    final int MAX = 10; // set the maximum number between banana pieces
    final int LOW = 0; // set the minimum number so doesnt go below 0
    final int STEP = 1; // sets maximum step size
    
    int max; // set the maximum number banana pieces
    int min;// sets the minimum number banana pieces 
    double stepSize; //sets the curry concentration step size
    
    Scanner sc = new Scanner(System.in);
    
    boolean resume = true; //checks if exceeds Threshold and if step (concentration < 1.0) is true
    
   
    while(resume){
      
      displayHeading("The local Chocolate Factory");
      
      System.out.print("Enter the minimum number of banana pieces:");
      min = sc.nextInt();
      
      System.out.println("Enter the maximum number of banana pieces:");
      max = sc.nextInt();
     
      System.out.println("Enter the curry concentration step size:");
      stepSize = sc.nextDouble();
      
      if ((min < LOW) || (max < LOW) || (stepSize < LOW) || (min > max) || ((max - min) >= MAX) || (stepSize > STEP)){
        System.out.println("Sorry, these are not legal");
        
      } else {
        System.out.println();
        System.out.println("Number of banana pieces");
        System.out.print("Curry");
        
        for (int i = min; i <= max; i++) {
          System.out.print(" |  " + i + " ");
        }
        System.out.println();
        
        Curry c = new Curry(stepSize);
        SweetFA sweetFA = new SweetFA(c, min);
        do {
          System.out.print(sweetFA.getConcentration());
          for (int i = min; i <= max; i++) {
            sweetFA.setNumBananaPieces(i);
            sweetFA.calculateFlavour();
            System.out.print(" | " + sweetFA);
          }
          System.out.println();
          resume = (sweetFA.getConcentration().nextStep() && !sweetFA.exceedsThreshold());
        }
        while (resume);
      }
      System.out.println();
    }
  }
  
}

