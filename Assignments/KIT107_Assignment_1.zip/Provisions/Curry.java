import java.text.DecimalFormat;
/*
 * Assignment 1
 * Curry -- Implementation for KIT107 Assignment 1
 * @author Zac Partridge 597945 & 
 * @version 09/03/2022
 */

public class Curry implements CurryInterface {
  
  protected static final DecimalFormat FMT = new DecimalFormat("0.00"); // format for Curry values
  
  /**
   * 'Constructor' for Curry
   * 
   * @param super() for SweetFA(Curry c, int n)
   * @param s value for step field
   * @param concentration value for step field
   * 
   *          Pre-condition: none
   *          Post-condition: the curry instance variable is assigned the value of
   *          the formal parameter s and the concentration instance
   *          variable is assigned the value of the formal parameter step
   */
  public Curry(double step){
    super();
    this.s = step;
    this.concentration = step;
  }
  
  private double concentration; // number of concentration
  private double s; // number of steps
  
  
  /**
   * Getter for step
   * 
   * @return s value of step field
   * 
   *         Pre-condition: none
   *         Post-condition: the value of the s instance variable is returned
   */
  public double getStep() {
    return s;
  }
  
  /**
   * Setter for step
   * 
   * @param s the value for the step field
   * 
   *          Pre-condition: none
   *          Post-condition: the value of the s instance variable is assigned
   *          the value of the formal parameter
   */
  public void setStep(double step) {
    s = step;
  }
   
  /**
   * Getter for concentration
   * 
   * @return concentration value of step field
   * 
   *         Pre-condition: none
   *         Post-condition: the value of the concentration instance variable is returned
   */
  public double getConcentration() {
    
    return concentration;
  }
  /**
   * Check whether step exceeds 1.0
   * 
   * @return boolean whether the step exceeds the 1.0
   * 
   *         Pre-condition: the current object's concentration instance variable is
   *         defined
   *         Post-condition: whether the value of the concentration instance variable
   *         exceeds the 1.0 is determined and returned
   */
  public boolean nextStep() {
    if (concentration < 1.0) {
      concentration += s;
      return true;
    }
    return false;
  }
  /**
   * Find printable form of concentration
   * 
   * @return String form of concentration for printing etc.
   * 
   *         Pre-condition: the current object's concentration instance variable is
   *         defined
   *         Post-condition: a String is returned which contains a 'prettified'
   *         version of the value of the concentration instance variable
   */
  public String toString()
  {
    return (FMT.format(concentration) + " ");
  }
}