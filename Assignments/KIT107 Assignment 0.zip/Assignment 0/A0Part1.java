/*
 * Assignment 0 
 * Task 1 -- Swap two values
 * @author Zac Partridge 597945
 * @version 24/02/2022
 */

public class A0Part1 {

  public static void main(String[] args) {
    char a = 'A'; // assigning first value
    char b = '$'; // assigning second value
    char temp; // assigning temp value

    System.out.println("Before swapping vaule: a is " + a + " and b is " + b + ".");

    // swaping values
    temp = a;
    a = b;
    b = temp;

    System.out.println("After swapping vaule: a is " + a + " and b is " + b + ".");

  }
}