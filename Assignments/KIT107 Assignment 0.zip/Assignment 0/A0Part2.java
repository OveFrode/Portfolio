import java.util.Scanner;

/*
 * Assignment 0 
 * Task 2 -- enter two int variables and show the numbers inbetween
 * @author Zac Partridge 597945
 * @version 24/02/2022
 */
public class A0Part2 {
  
   public static void main(String[] args) 
    {
     Scanner sc = new Scanner(System.in);
     int x; //the first vaule
     int y; //the second vaule
     int temp; //temp vaule in case vaules need to be swapped
     
     //to get users value input
     System.out.print("Please enter your first number: ");
     x=sc.nextInt();
     System.out.print("Please enter your second number: ");
     y=sc.nextInt();
     
     //if x is less then y vaule swaps
     if (x > y)
     {
       temp = x;
       x = y;
       y = temp;
     }
     
     //to print out the numbers inbetween x and y
     for (int i = x; i <= y; i++)
     {
       System.out.print(i + ", ");
     }
     
   }
}
  