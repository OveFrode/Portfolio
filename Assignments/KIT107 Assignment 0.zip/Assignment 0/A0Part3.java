import java.util.Scanner;

/*
 * Assignment 0 
 * Task 3 -- reads up to 10 numbers then getting the sum of them and displaying the result
 * @author Zac Partridge 597945
 * @version 24/02/2022
 */

public class A0Part3 {
  
  public static void main(String[] args) 
    {
    final int LIMIT = 10; //so the array doesnt go past 10
    final double END = -1.0; //Ends the program
    
    Scanner sc = new Scanner(System.in);
   
    double[] numbers = new double[LIMIT]; // initialise array
    double currentNum; // to check the current entered number
    int count; // counts of how many numbers have been entered
    double sum; // sum of all numbers entered
    
    count = 0; // sets the start point of count
    sum = 0.0; // sets the start point of sum
    
// get numbers
    System.out.print("Please enter a number (�1.0 to Stop): ");
    currentNum=sc.nextDouble();
    
   //to check if number entered is -1.0 or if array is over 10
    while ((count < LIMIT) && (currentNum != END)) 
    {
      numbers[count] = currentNum; // store number
      sum = sum + numbers[count]; // include in sum
      count++; // move to next array element
     if (count < LIMIT) // to make sure there is still room in array.(otherwise it goes to 11 not 10)
      {
        System.out.print("Please enter another number (�1.0 to stop): ");
        currentNum=sc.nextDouble();
      }
    }
// display sum
    System.out.println("Sum is: " + sum);
  }
  
}